import React from "react";

const Footer = props => {
    return(
      <footer>
        <div className="add-player">
          <form onSubmit={props.addPlayer}>
            <input type="text" value={props.play} onChange={props.addPlayer}/>
            <input type="submit" value="Add Player" />
          </form>
        </div>
      </footer>
    )
  }

  export default Footer;