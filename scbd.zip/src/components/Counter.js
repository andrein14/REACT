import React from 'react';
 
const Counter = (props) => {

    return (
      <div className="counter">
        <button onClick={ () => props.changeScore(props.id) } className="counter-action decrement">-</button>
        <span className="counter-score">{props.score}</span>
        <button onClick={ () => props.changeScore(props.id) } className="counter-action increment">+</button>
      </div>);
}

export default Counter;
