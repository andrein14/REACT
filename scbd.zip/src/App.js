import React, { Component } from "react";
import { PLAYERS } from "./shared/players";
import Header from "./components/Header";
import Player from "./components/Player";
import Footer from "./components/Footer";

class App extends Component {
  state = { players: PLAYERS };

  handleScoreChange = (id, direction) => {
   
    for(var i = 0; i < this.state.players.length; i++){

      // console.log(this.state.players[id].score);
      //this.setstate.players[id].score
   }

    // this.setState({players: newPlayers})
   
  }

  removePlayer(id) {
    this.setState(prevState=>(
      {players: prevState.players.filter(players => players.id !== id)}
    ));
  }

  render() {
    return (
      <div className="scoreboard">
        <Header playersNumber={this.state.players.length} />
        {this.state.players.map(player => (
            <Player 
              id={player.id}
              key={player.id.toString()}
              playersName={player.name}
              removePlayer={() => this.removePlayer(player.id)}
              score={player.score}
              changeScore = {this.handleScoreChange}
            />
          ))
        }
        <Footer />
      </div>
    );
  }
}

export default App;