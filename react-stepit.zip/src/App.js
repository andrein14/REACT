import React, { Component } from "react";
import { PLAYERS } from "./shared/players";
import Header from "./components/Header";
import Player from "./components/Player";


class App extends Component {
  state = { players: PLAYERS };

  removePlayer =(id) => {
    this.setState(prevState=>(
      {players: prevState.players.filter}
    ));
  }

  render() {
    return (
      <div className="scoreboard">
        <Header playersNumber={this.state.players.length} />
        {this.state.players.map(player => (
            <Player playersName={player.name}/>
          ))
        }
      </div>
    );
  }
}

export default App;