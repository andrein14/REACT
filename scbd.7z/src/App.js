import React, { Component } from "react";
import { PLAYERS } from "./shared/players";
import Header from "./components/Header";
import Player from "./components/Player";
import Footer from "./components/Footer";

class App extends Component {
  state = { players: PLAYERS };

  // addPlayer (playersName) {
  //   this.state.players.push({
  //     name: name,
  //     score: 0,
  //     id: newId
  //   });
  //   this.setState(this.state)
  //   newId += 1
  // }

  handleScoreChange = (playerIndex, direction) =>{
    this.setState(
      {
        players : this.state.players.map( (item) => {
        item = (item.id === playerIndex) ? Object.assign(item, {score: item.score + direction}) : item
          return item
          }
        )
      }
    );
  }

  removePlayer(id) {
    this.setState(prevState=>(
      {players: prevState.players.filter(players => players.id !== id)}
    ));
  }

  render() {
    return (
      <div className="scoreboard">
        <Header playersNumber={this.state.players.length} 
                players = {this.state.players}/>
        {this.state.players.map(player => (
            <Player 
              id={player.id}
              key={player.id.toString()}
              playersName={player.name}
              removePlayer={() => this.removePlayer(player.id)}
              score={player.score}
              changeScore = {this.handleScoreChange}
            />
          ))
        }
        <Footer />
      </div>
    );
  }
}

class AddPlayerForm extends Component {
  state = { value : '' }

  render() { 
    //<input name="myData" id="myData" value={this.state.value}  />
    return (console.log("HELLO"));
  }
}


export default App;