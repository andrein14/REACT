export const PLAYERS =
[
    {
    id: 0,
    name:'GUIL',
    score: 0
    },
    {
    id: 1,
    name:'TREASURE',
    score: 0
    },
    {
    id: 2,
    name:'ASHLEY',
    score: 0
    },
    {
    id: 3,
    name:'JAMES',
    score: 0
    }
];