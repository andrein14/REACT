import React from "react"

const Stats = (props) => {

    var score = 0; 
    for(var i = 0; i < props.playersNumber; i++){
        score += props.players[i].score;
    }
    
    return(    
       
<table className="stats">
  <tbody>
    <tr>
      <td>Players:</td>
      <td>{props.playersNumber}</td>
    </tr>
    <tr>
      <td>Total Points:</td>
      <td>{score}</td>
    </tr>
  </tbody>
</table>
    );
}

export default Stats