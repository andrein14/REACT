import React from "react";
import Stats from "./Stats"

const Header = props => {
    return (
      <header>
        <span className="stats">
          <Stats playersNumber = {props.playersNumber}
                 players ={props.players}/>
        </span>
        <h1>Scoreboard</h1>
      </header>
    );
};

export default Header;