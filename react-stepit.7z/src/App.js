import React, { Component } from "react";
import Header from "./components/Header";
import { PLAYERS } from "./shared/players";
import Player from "./components/Player";
import Counter from "./components/Counter"

class App extends Component {
  state = { players: PLAYERS };

  render() {
    return (
      <div className="scoreboard">
      <Header playersNumber = {this.state.players.length}/>
      
      <Player playersName = {this.state.players[0].name}/> <Counter />
      
      </div>
    );
  }
}

export default App;
