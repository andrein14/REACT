import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import "./scoreboard.css";

ReactDOM.render(<App />, document.getElementById('root'));