import React from "react";

const Player = props => {
  return (
    <div className="player">
      <span className="player-name">
        <button className="remove-player">✖</button>{props.playersName}
      </span>
    </div>
  );
};
export default Player;
