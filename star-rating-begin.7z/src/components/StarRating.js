import React, { Component } from "react";
import Star from './Star';

class StarRating extends Component {

  // 1. Initialize a 'rating' state
    state = {
      rating: 0
    }

  // 2. Write a function that returns 5 Star components
    showStars = () => {
      const stars=[];
      
      for(let i=0; i < 5; i++)
      stars.push(
        <Star 
          key={i.toString()}
          updateRating={this.updateRating}
        />
      )
      return stars;
    }

  // 3. Write an event handler that updates the rating state.
  updateRating(rating) {
    this.setState({rating: rating});
    console.log("asd")
}
  // 4. Pass the function to a Star component via props


  render() {
    return (
      <ul className="course--stars">
      {this.showStars()}
      </ul>
    );
  }
}

export default StarRating;