
export const PLAYERS = 
[
  {
    name: "Guil",
    score: 0,
    id: 0,
    isMax:false
  },
  {
    name: "Treasure",
    score: 0,
    id: 1,
    isMax:false
  },
  {
    name: "Ashley",
    score: 0,
    id: 2,
    isMax:false
  },
  {
    name: "James",
    score: 0,
    id: 3,
    isMax:false
  }
];