export const PLAYERS =
[
    {
    id: 0,
    name:'GUIL',
    },
    {
    id: 1,
    name:'TREASURE',
    },
    {
    id: 2,
    name:'ASHLEY'
    },
    {
    id: 3,
    name:'JAMES',
    }
];