import React, { Component } from "react";
import { PLAYERS } from "./shared/players";
import Header from "./components/Header";
import Player from "./components/Player";
import Counter from "./components/Counter"

class App extends Component {
  state = { players: PLAYERS };

  render() {
    return (
      <div className="scoreboard">
        <Header playersNumber={this.state.players.length} />
        {this.state.players.map(players => {
          return (<div>
            <div className="player"><Player playersName={players.name}/>
              <span className="player-name"></span>
              <div className="counter"><Counter /></div>
            </div>
            </div>
            )
           }
         )
        }
      </div>
    );
  }
}

export default App;
